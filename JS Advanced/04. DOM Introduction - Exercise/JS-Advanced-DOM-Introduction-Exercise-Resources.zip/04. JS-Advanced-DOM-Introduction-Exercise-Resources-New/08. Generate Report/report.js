function generateReport(colNames) {
    //TODO
}